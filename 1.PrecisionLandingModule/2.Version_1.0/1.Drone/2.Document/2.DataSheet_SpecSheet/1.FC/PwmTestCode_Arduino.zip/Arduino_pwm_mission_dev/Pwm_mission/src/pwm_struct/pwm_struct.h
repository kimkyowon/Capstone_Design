#ifndef PWM_STRUCT_h
#define PWM_STRUCT_h

#include <Arduino.h>
#include "stdint.h"

const int PWM_ERROR_MARGIN = 35;
constexpr uint16_t PWM_RANGE_MIN = 1000;
constexpr uint16_t PWM_RANGE_MAX = 2000;

class PWM{
public:
    uint16_t _pin;
    PWM(int pinnum);
    int _pwmFilter(const int _pwm, const int _margin);
    bool is_pwm_change();
    uint16_t get_val();
    void change_sw_val();
    void print_status();
    uint16_t _val;
    uint16_t _previous_val;
    uint16_t _raw_val;
    uint16_t _timer;
    uint16_t _read_pwm[3];
    uint16_t _read_cnt;
};

class Main_pwm{
public:
    uint16_t _mission_previous_pwm;
    uint16_t _mission_current_pwm;
};


#endif