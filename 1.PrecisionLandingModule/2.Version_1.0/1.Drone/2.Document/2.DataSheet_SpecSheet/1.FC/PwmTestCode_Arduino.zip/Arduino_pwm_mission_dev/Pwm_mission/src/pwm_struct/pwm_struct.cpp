#include "pwm_struct.h"

extern uint16_t flag_whichpwm;

PWM::PWM(int pinnum){
    this->_pin = pinnum;
}


bool PWM::is_pwm_change(){
    if(this->_val == this->_previous_val) return false;
    else {
        this->print_status();
        this->_previous_val = this->_val;
    }
    return true;    
}

uint16_t PWM::get_val(){
    return this->_val;
}

void PWM::change_sw_val(){
   this-> _previous_val = this->_val;   //sw 변경 후 동작되도록 백그라운드에서 값 동기화 계속 진행. 
}

void PWM::print_status(){
    Serial.print(this->_pin);
    Serial.print("[ Previous ] :");
    Serial.print(this->_previous_val);
    Serial.print("      ===>     [ Current ] : ");
    Serial.print(this->_val);
    Serial.print(" [ Raw Val ] : ");
    Serial.println(this->_raw_val);
}





